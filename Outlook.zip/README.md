# NAOS SLA Tracker

Настольное приложение (CLI + PySide6 UI) для ежедневного ведения обращений: Outlook ingest, SQLite, защищённый Excel, напоминания, голосование по письмам и быстрый action center.

## Что внутри
- Один сценарий по кнопке: Sync Excel → Outlook ingest → пересчёт SLA → экспорт Excel → обработка ответов → (опционально) рассылка просрочек с антиспамом.
- SQLite с `row_version`, `events`, `is_repeat/repeat_hint`, `recommended_answer`, `priority`, `comment`.
- Excel: листы «Обращения»/«Просрочки»/KPI/«Конфликты»/справка статусов; защищён всё, кроме Статус/Ответственный/Приоритет/Комментарий; пароль задаётся в `excel_password`.
- Outlook: voting (OK / Нужно время / Закрыть / Ждём клиента), команды `/status /prio /owner /comment`, тихие часы и интервал повторных напоминаний.
- Рекомендации: TF‑IDF по базе (30д) + скрипты из `NAOS_ORM_master script.xlsx`.

## Быстрый старт
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python cli.py ui        # запустить новый UI
python cli.py ingest --days 7
python cli.py recalc-open
python cli.py export-xlsx
python cli.py sync-excel
python cli.py send-overdue
python cli.py process-responses --days 7
python cli.py test-all
python cli.py diagnose --days 7
```

## Конфиг (`%APPDATA%/NAOS_SLA_TRACKER/config.json`)
- Основное: `ingest_days`, `overdue_days`, `safe_mode`, `allow_send`, `quiet_hours_start/end`, `reminder_interval_hours`, `excel_password`, `docs_url/sharepoint_url`.
- Outlook: `mailbox`, `folder`, `sender_filter_mode` (off/contains/equals/domain), `sender_filter_value`.
- Пути: `paths.*` (db/excel/logs/backups/orm_script_path).
- SLA: `sla_by_priority`, `escalation_matrix`, `status_catalog/status_hints`.
- Пример: `config.example.json`.

## Новый UI
- Главная: большая кнопка «Запустить сценарий (утро/вечер)», карточки метрик, таблица «Требуют внимания», панель деталей (тема, клиент, SLA, рекомендации, события).
- Быстрые правки без Excel: статус (RU), ответственный, приоритет, комментарий, кнопка «Отправить ремайндер».
- Живой чат‑лог (QPlainTextEdit + командная строка), подключён к logging.Handler. Команды: `help`, `sync`, `ingest`, `export`, `send`, `process`, `diagnose`, `open excel`.
- Настройки: простой режим (ingest_days, SAFE/SEND, ссылка на гайд, пароль Excel), расширенный (mailbox/folder/filter).
- «Тест проставки статуса (демо)»: создаёт просроченный тикет, шлёт тестовое письмо, инструкция показана в логе.

## Excel
- Листы: «Обращения», «Просрочки», KPI, «Конфликты», «Справка статусов».
- Редактируемые колонки: Статус/Ответственный/Приоритет/Комментарий (остальное заблокировано, лист защищён паролем из конфига).
- Цветовая подсветка статусов, списки значений для Статус и Приоритет, конфликтные строки логируются в events (`excel_conflict`) и лист «Конфликты».

## CLI поведение send-overdue
- `reminder_interval_hours` и quiet-hours блокируют повторные отправки; `overdue_plan` возвращает категории `send/skip_interval/skip_quiet/skip_no_responsible`, UI и CLI показывают причины пропуска.

## Тесты
```
pytest
```
Покрыто: маппинг статусов RU/EN, roundtrip Excel→DB, защита Excel, блокировка повторных напоминаний.

## Сборка
```
build.bat   # ставит зависимости, собирает PyInstaller (cli + ui)
```
`naos_sla.spec` включает win32com/PySide6, README/RUNBOOK/config.example/NAOS_ORM_master script.xlsx. При старте exe данные пишутся в `%APPDATA%/NAOS_SLA_TRACKER`.

## QA ������ (������)
```python cli.py qa-full --send  # ��� ��� --send ��� Display
```- ��������� pytest;
- ��������� semi-E2E ������� (qa/tools/qa_e2e_driver.py), ��� Voting � Outlook;
- ����� ����� %APPDATA%/NAOS_SLA_TRACKER/QA_REPORT.md.
