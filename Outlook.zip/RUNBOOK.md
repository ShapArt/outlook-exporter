# RUNBOOK — NAOS SLA Tracker

## Единый сценарий (утро/вечер)
1) Открыть UI (`python cli.py ui` или exe). На главной: метрики, таблица «Требуют внимания», чат‑лог.
2) Нажать «Запустить сценарий (утро/вечер)». В логе видно:
   - Sync Excel → DB (updated/conflicts/missing)
   - Ingest Outlook за `ingest_days`
   - Пересчёт SLA/overdue/days_without_update
   - Export Excel (с конфликтами, если были)
   - Process responses
   - Send overdue (антиспам: interval/quiet-hours/нет ответственного — показано в логе)
   - Итоговая строка с цифрами
3) Если нужно вручную: статусы/ответственные правятся в таблице или Excel (Статус/Ответственный/Приоритет/Комментарий).

## Action Center
- Фильтры: Все / Требуют действий / Просрочено / Без ответственного / Конфликты Excel.
- Панель деталей: тема, клиентский email, статус, SLA, рекомендация, текст обращения, события.
- Быстрые действия: Статус (RU), Ответственный, Приоритет, Комментарий, «Отправить ремайндер», «Открыть письмо в Outlook», «Открыть Excel».
- Если нет ответственного или конфликт Excel — видно в таблице/истории событий.

## Живой чат‑лог
- QSplitter: верх — дашборд/таблица, низ — чат‑лог.
- Команды: `help`, `sync`, `ingest`, `export`, `send`, `process`, `diagnose`, `open excel`.
- В логе падают все `logging.info/warning/error` из core/* (handler → Qt signal → appendPlainText, с max blocks).

## Демонстрации
- **Тест проставки статуса (демо)**:
  1. Кнопка в UI создаёт overdue-тикет и шлёт тестовое письмо (allowlist).
  2. Открыть письмо, нажать Voting «Закрыть» или ответить `/status closed`.
  3. Нажать «Process responses» или общий сценарий — в логе: «нашли X ответов, обновили Y тикетов», статус до/после в таблице.
- **Send overdue два раза**: второй запуск покажет в логе `skip_interval`/`quiet`/`no_responsible`, писем не уйдёт.

## Excel
- Листы: «Обращения», «Просрочки», KPI, «Конфликты», «Справка статусов».
- Защита: разблокированы только Статус/Ответственный/Комментарий/Приоритет; пароль `excel_password` (config).
- Поля для анализа: `Частота похожих (30д)`, `Топ-тема`, `Рекомендация ответа`.
- Конфликты sync: логируются в events (`excel_conflict`) + лист «Конфликты».

## Конфиг (важное)
- Основное: `ingest_days`, `quiet_hours_start/end`, `reminder_interval_hours`, `safe_mode`/`allow_send`, `excel_password`, `docs_url/sharepoint_url`.
- Outlook: `mailbox`, `folder`, `sender_filter_mode/value`.
- Рекомендации: `orm_similarity_days`, `orm_similarity_threshold`, `orm_max_suggestions`, `orm_script_path` (по умолчанию `NAOS_ORM_master script.xlsx`).

## Сборка/развёртывание
- `build.bat` → PyInstaller (cli + ui). В дистрибутив кладутся README/RUNBOOK/config.example/config.json/NAOS_ORM_master script.xlsx.
- При старте exe создаёт `%APPDATA%/NAOS_SLA_TRACKER`, пишет лог туда, предупреждает, если только New Outlook.

## Тесты
- `pytest` — статус‑маппинг, excel roundtrip, защита листов, блокировка повторных напоминаний.
